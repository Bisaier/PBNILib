﻿//**************************************************************************
//
//  PBNILib.h — PBNI 完整框架 (v2.2)
//
//  四类注册型（宏驱动，自动导出给 PB 调用）+ 一类宿主型（独立类）：
//    1. NVO          — 非可视对象（业务逻辑扩展）
//    2. Visual       — 可视控件（自定义窗口控件）
//    3. Global       — 全局函数（PB 脚本直接调的函数）
//    4. Marshaler    — 代理对象（远程调用 / 跨进程通信）
//    5. PBVM Host    — 宿主程序（C++ EXE 嵌入 PB 虚拟机）← 不走注册表
//
//  四张独立注册表（std::vector），各走各路，互不耦合。
//  你用 NVO → 另外三张表为空 → 零开销。
//
//  依赖：pbext.h + tchar.h + <vector> + <string>，纯 C++03 语法
//  兼容：PB 12.5 + VS2010 + Win7/10
//
//**************************************************************************
#ifndef PBNILIB_H
#define PBNILIB_H

// ========================== 头文件依赖 ==========================
// pbext.h 包含 PBX_GetDescription / PBX_CreateNonVisualObject 等导出函数声明
//          以及 IPBX_NonVisualObject / IPBX_VisualObject / IPBX_Marshaler 接口
#include <pbext.h>

// tchar.h 提供 TCHAR / _T() / _tcscmp / _sntprintf_s，自动适配 Unicode/ANSI
#include <tchar.h>

// std::vector 提供动态数组，注册表无上限，自动扩容
#include <vector>

// std::basic_string 提供动态字符串，GetDescription 无大小限制
#include <string>

// 类型别名：自动适配 Unicode（wstring）/ ANSI（string）
typedef std::basic_string<TCHAR> tstring;

//==========================================================================
//  一、数据结构定义 —— 四张注册表共用的基本类型
//==========================================================================

// ---- 方法描述项：一条 PB 方法声明的编号和字符串 ----
struct PBNIMethod
{
    pbuint   mid;        // 方法编号（0, 1, 2...），PB 调用 Invoke 时传这个
    LPCTSTR  signature;  // PB 声明字符串，如 "function int of_add(int a, int b)"
};

// ---- NVO 注册项：描述一个非可视对象类 ----
struct PBNINvoInfo
{
    LPCTSTR      name;          // PB 类名，如 "n_cpp_math"
    LPCTSTR      baseClass;     // PB 父类，如 "nonvisualobject"
    PBNIMethod  *methods;       // 指向静态方法表的指针
    int          methodCount;   // 方法个数
    void       *(*create)(IPB_Session *session);   // 工厂函数指针（返回 C++ 对象）
};

// ---- Visual 注册项：描述一个可视控件类 ----
struct PBNIVisualInfo
{
    LPCTSTR      name;          // PB 类名，如 "u_cpp_box"
    PBNIMethod  *methods;       // 指向静态方法表的指针
    int          methodCount;   // 方法个数
    void       *(*create)(IPB_Session *session, pbobject obj); // 工厂函数
};

// ---- 全局函数注册项：描述一个 PB 全局函数 ----
struct PBNIGlobalInfo
{
    LPCTSTR      name;          // PB 函数名，如 "f_version"
    LPCTSTR      signature;     // PB 声明，如 "function string f_version()"
    PBXRESULT  (*func)(IPB_Session *session, PBCallInfo *ci); // 实现函数指针
};

// ---- Marshaler 注册项：描述一个代理类 ----
struct PBNIMarshalerInfo
{
    LPCTSTR      name;          // PB 类名，如 "n_cpp_proxy"
    PBNIMethod  *methods;       // 指向静态方法表的指针
    int          methodCount;
    void       *(*create)(IPB_Session *session, pbproxyObject obj); // 工厂
};

// ---- DllMain 钩子类型：用于 Visual 控件的窗口类注册/注销 ----
typedef void (*PBNIDllHook)(HINSTANCE h);


//==========================================================================
//  二、注册表 —— Meyer's Singleton，延迟初始化，无静态顺序问题
//
//  为什么用函数包装 static vector 而不是全局变量？
//    不同 .cpp 文件的全局对象初始化顺序是未定义的。
//    如果 MyMath.cpp 的静态构造函数先跑了，而 pbnilib.cpp 的
//    vector 还没构造 → push_back 会崩。
//    Meyer's Singleton（函数内的 static 变量）保证第一次调用时才构造。
//==========================================================================
inline std::vector<PBNINvoInfo>&      NvoReg()
    { static std::vector<PBNINvoInfo>       r; return r; }

inline std::vector<PBNIVisualInfo>&   VisualReg()
    { static std::vector<PBNIVisualInfo>    r; return r; }

inline std::vector<PBNIGlobalInfo>&   GlobalReg()
    { static std::vector<PBNIGlobalInfo>    r; return r; }

inline std::vector<PBNIMarshalerInfo>& MarshalerReg()
    { static std::vector<PBNIMarshalerInfo> r; return r; }

inline std::vector<PBNIDllHook>&      InitHooks()
    { static std::vector<PBNIDllHook>       r; return r; }

inline std::vector<PBNIDllHook>&      CleanupHooks()
    { static std::vector<PBNIDllHook>       r; return r; }


//==========================================================================
//  三、基类 —— 用户定义的类继承这些，获得 PBNI 能力
//==========================================================================

// ---- NVO 基类：自动提供 Destroy（delete this），存储 d_session ----
class PBNIBase : public IPBX_NonVisualObject
{
public:
    PBNIBase(IPB_Session *session) : d_session(session) {}

    // PB 调用 DESTROY obj 时触发，固定写法 delete this
    virtual void Destroy() { delete this; }

    // 子类通过 PBNI_REGISTER_NVO_INVOKE 宏重写这个方法
    virtual PBXRESULT Invoke(IPB_Session*, pbobject, pbmethodID mid, PBCallInfo* ci)
    {
        (void)mid; (void)ci;
        return PBX_E_INVOKE_METHOD_AMBIGUOUS;
    }

protected:
    IPB_Session *d_session;  // PB 会话指针，子类方法里用它调 PB 的东西
};

// ---- Marshaler 基类：提供 GetModuleHandle + Destroy + 存储 session/obj ----
//  子类构造时把 (s, o) 传给基类即可，无需自己声明 m_s / m_obj
//  d_obj 由 PB 管理生命周期（PB 保证 C++ 扩展先于 PB 对象销毁），无需 AddRef
class PBNIMarshalerBase : public IPBX_Marshaler
{
public:
    PBNIMarshalerBase(IPB_Session *session, pbproxyObject obj)
        : d_session(session), d_obj(obj) {}
    virtual pbulong GetModuleHandle() { return 0; }
    virtual void Destroy() { delete this; }

protected:
    IPB_Session   *d_session;   // PB 会话
    pbproxyObject  d_obj;       // PB 端代理对象句柄
};

// ---- Visual 基类：提供 Destroy / GetEventID / 成员变量，减少样板 ----
//  子类只需实现：GetWindowClassName(), CreateControl(),
//                RegisterWndClass(HINSTANCE), UnregisterWndClass(HINSTANCE)
//  Invoke() 由 PBNI_REGISTER_VISUAL_INVOKE 宏自动生成
//  d_obj 由 PB 管理生命周期（PB 保证 C++ 扩展先于 PB 对象销毁），无需 AddRef
class PBNIVisualBase : public IPBX_VisualObject
{
public:
    PBNIVisualBase(IPB_Session *session, pbobject obj)
        : d_session(session), d_obj(obj), d_hWnd(NULL) {}
    virtual ~PBNIVisualBase() {}

    virtual void Destroy() { delete this; }

    // 默认不转发 PB 事件（返回 PB_NULL）。如需转发，子类重写即可。
    virtual int GetEventID(HWND, UINT, WPARAM, LPARAM) { return PB_NULL; }

protected:
    IPB_Session *d_session;   // PB 会话
    pbobject     d_obj;       // PB 端控件对象
    HWND         d_hWnd;      // Windows 窗口句柄
};


//==========================================================================
//  四、PBVM 宿主类 —— 在 C++ EXE 中嵌入 PB 虚拟机
//
//  用法示例：
//    int main() {
//        PBNIHost host;
//        IPB_Session *s = host.Start(_T("myapp.pbt"));
//        if (!s) return 1;
//        pbobject obj = s->NewObject(cls);
//        // ... 使用 PB ...
//        host.Stop();
//        return 0;
//    }
//==========================================================================
class PBNIHost
{
public:
    PBNIHost() : d_session(NULL) {}
    ~PBNIHost();

    // 启动 PB 会话。appName 是 PB target 路径，cmdLine 是可选命令行参数。
    // 先调 CreateSession（不启动 PB 界面），如果 cmdLine 非空则调 RunApplication。
    // 返回 IPB_Session*，失败返回 NULL。
    IPB_Session* Start(LPCTSTR appName, LPCTSTR cmdLine = _T(""));

    // 释放当前会话，可以再次 Start
    void Stop() {
        if (d_session) { d_session->Release(); d_session = NULL; }
    }

    // 便捷访问：host->NewObject(cls) 等价于 host.Get()->NewObject(cls)
    IPB_Session* operator->() const { return d_session; }
    IPB_Session* Get()        const { return d_session; }

private:
    IPB_Session *d_session;  // 当前会话，持有所有权（需 Release）
};


//==========================================================================
//  五、内部注册辅助函数 + 宏 —— 把编译期信息写入 runtime 注册表
//
//  辅助函数负责 push_back，宏负责生成 static int 触发静态初始化。
//  为什么用函数而不用宏内声明变量？
//    MSVC 不支持在逗号表达式 () 内声明局部变量（GCC 扩展），
//    改为函数调用后每个宏展开只是一个表达式，兼容所有编译器。
//==========================================================================

// ---- 辅助函数：避免宏内部声明变量，兼容 MSVC ----
inline int _reg_nvo(LPCTSTR name, LPCTSTR baseClass,
                    PBNIMethod *methods, int methodCount,
                    void *(*create)(IPB_Session*))
{
    PBNINvoInfo e;  e.name = name;  e.baseClass = baseClass;
    e.methods = methods;  e.methodCount = methodCount;  e.create = create;
    NvoReg().push_back(e);  return 0;
}

inline int _reg_visual(LPCTSTR name, PBNIMethod *methods, int methodCount,
                       void *(*create)(IPB_Session*, pbobject))
{
    PBNIVisualInfo e;
    e.name = name;  e.methods = methods;
    e.methodCount = methodCount;  e.create = create;
    VisualReg().push_back(e);  return 0;
}

inline int _reg_global(LPCTSTR name, LPCTSTR signature,
                       PBXRESULT (*func)(IPB_Session*, PBCallInfo*))
{
    PBNIGlobalInfo e;
    e.name = name;  e.signature = signature;  e.func = func;
    GlobalReg().push_back(e);  return 0;
}

inline int _reg_marshaler(LPCTSTR name, PBNIMethod *methods, int methodCount,
                          void *(*create)(IPB_Session*, pbproxyObject))
{
    PBNIMarshalerInfo e;
    e.name = name;  e.methods = methods;
    e.methodCount = methodCount;  e.create = create;
    MarshalerReg().push_back(e);  return 0;
}

// ---- 注册宏：一个表达式搞定，不再在 () 内声明变量 ----
#define PBNI_ADD_NVO(ClsName, factoryFn)                                \
    static int _nvo_##ClsName = _reg_nvo(ClsName##_desc_name,           \
        ClsName##_desc_base, ClsName##_mt,                              \
        sizeof(ClsName##_mt) / sizeof(PBNIMethod), factoryFn);

#define PBNI_ADD_VISUAL(ClsName, factoryFn)                             \
    static int _vis_##ClsName = (                                       \
        InitHooks().push_back(ClsName##_init_hook),                     \
        CleanupHooks().push_back(ClsName##_cleanup_hook),               \
        _reg_visual(ClsName##_desc_name, ClsName##_mt,                 \
            sizeof(ClsName##_mt) / sizeof(PBNIMethod), factoryFn));

#define PBNI_ADD_GLOBAL(FuncName)                                       \
    static int _gbl_##FuncName = _reg_global(FuncName##_desc_name,      \
        FuncName##_desc_sig, FuncName##_body);

#define PBNI_ADD_MARSHALER(ClsName, factoryFn)                          \
    static int _msh_##ClsName = _reg_marshaler(ClsName##_desc_name,     \
        ClsName##_mt, sizeof(ClsName##_mt) / sizeof(PBNIMethod), factoryFn);


//==========================================================================
//  六、PBNI_DLL_MAIN —— 一键生成全部 7 个 DLL 导出函数
//
//  这是整个框架的"发动机"。用户在 main.cpp 里写一次 PBNI_DLL_MAIN()，
//  下面这些函数全部自动生成：
//    DllMain                   — Windows 标准入口 + Visual 窗口类注册/注销
//    PBX_Notify                — PB 通知（DLL 加载/卸载）
//    PBX_GetDescription        — 遍历全部注册表，拼出 PB 需要的类描述字符串
//    PBX_CreateNonVisualObject — 遍历 NVO 表，按类名创建 C++ 对象
//    PBX_CreateVisualObject    — 遍历 Visual 表，按类名创建控件对象
//    PBX_InvokeGlobalFunction  — 遍历全局函数表，按函数名调用
//    PBX_DrawVisualObject      — PB 设计器预览 Visual 控件时调用
//==========================================================================

// ---- 内部辅助：格式化追加到 tstring（_sntprintf_s 为 MSVC 专有，非跨平台） ----
#define _FMT(dst, fmt, ...)                                              \
    do {                                                                 \
        TCHAR _b[512];                                                   \
        int _n = _sntprintf_s(_b, 512, _TRUNCATE, _T(fmt), __VA_ARGS__); \
        if (_n >= 0) dst.append(_b, _n); else dst.append(_b);            \
    } while(0)

#define PBNI_DLL_MAIN()                                                 \
                                                                        \
    /* ---- DllMain：Windows DLL 入口，Visual 控件钩子在此执行 ---- */   \
    BOOL APIENTRY DllMain(HANDLE h, DWORD r, LPVOID p) {               \
        (void)p; /* lpReserved，保留未用 */                              \
        HINSTANCE hi = (HINSTANCE)h;                                    \
        switch (r) {                                                    \
            case DLL_PROCESS_ATTACH: /* DLL 加载 */                     \
                /* 遍历全部 Visual 控件的 RegisterWndClass */            \
                for (size_t _k = 0; _k < InitHooks().size(); _k++)     \
                    InitHooks()[_k](hi);                                 \
                break;                                                  \
            case DLL_PROCESS_DETACH: /* DLL 卸载 */                     \
                /* 遍历全部 Visual 控件的 UnregisterWndClass */          \
                for (size_t _k = 0; _k < CleanupHooks().size(); _k++)  \
                    CleanupHooks()[_k](hi);                              \
                break;                                                  \
            case DLL_THREAD_ATTACH: case DLL_THREAD_DETACH: break;      \
        } return TRUE;                                                  \
    }                                                                   \
                                                                        \
    /* ---- PBX_Notify：PB 加载/卸载通知 ---- */                        \
    PBXEXPORT PBXRESULT PBXCALL PBX_Notify(IPB_Session *s, pbint r)    \
    {                                                                   \
        /* kAfterDllLoaded=1  kBeforeDllUnloaded=2                      \
           静态初始化器在 DllMain 之前已跑完，此处无需操作。               \
           取 PBX_GetVersion 地址强制编译器生成其导出符号                  \
           （pbext.h 定义为 inline，若无 ODR-use 可能不 emit）。           */ \
        (void)&PBX_GetVersion;                                          \
        (void)s; (void)r;                                               \
        return PBX_OK;                                                  \
    }                                                                   \
                                                                        \
    /* ---- PBX_GetDescription：拼出全部类/函数的 PB 描述串 ---- */        \
    PBXEXPORT LPCTSTR PBXCALL PBX_GetDescription() {                    \
        /* tstring 动态扩容，无 8192 限制。首次构建后缓存复用。 */          \
        static tstring _d;                                               \
        static bool _init = false;                                       \
        if (_init) return _d.c_str();                                    \
        _d.reserve(8192);                                                \
        size_t _i; int _j;                               \
        /* NVO 类描述 */                                                 \
        for (_i = 0; _i < NvoReg().size(); _i++) {                     \
            PBNINvoInfo *_c = &NvoReg()[_i];                             \
            _FMT(_d,"class %s from %s\n", _c->name, _c->baseClass); \
            for (_j = 0; _j < _c->methodCount; _j++)                    \
                _FMT(_d,"   %s\n", _c->methods[_j].signature); \
            _FMT(_d,"end class\n");                            \
        }                                                               \
        /* Visual 类描述（from userobject） */                           \
        for (_i = 0; _i < VisualReg().size(); _i++) {                  \
            PBNIVisualInfo *_c = &VisualReg()[_i];                      \
            _FMT(_d,"class %s from userobject\n", _c->name);  \
            for (_j = 0; _j < _c->methodCount; _j++)                    \
                _FMT(_d,"   %s\n", _c->methods[_j].signature); \
            _FMT(_d,"end class\n");                            \
        }                                                               \
        /* Marshaler 类描述（from nonvisualobject） */                   \
        for (_i = 0; _i < MarshalerReg().size(); _i++) {               \
            PBNIMarshalerInfo *_c = &MarshalerReg()[_i];                \
            _FMT(_d,"class %s from nonvisualobject\n", _c->name); \
            for (_j = 0; _j < _c->methodCount; _j++)                    \
                _FMT(_d,"   %s\n", _c->methods[_j].signature); \
            _FMT(_d,"end class\n");                            \
        }                                                               \
        /* 全局函数描述（如果有的话） */                                   \
        if (!GlobalReg().empty()) {                                     \
            _FMT(_d,"globalfunctions\n");                     \
            for (_i = 0; _i < GlobalReg().size(); _i++)                \
                _FMT(_d,"   %s\n", GlobalReg()[_i].signature); \
            _FMT(_d,"end globalfunctions\n");                  \
        }                                                               \
        _init = true;                                                    \
        return _d.c_str();                                               \
    }                                                                   \
                                                                        \
    /* ---- PBX_CreateNonVisualObject：PB 执行 CREATE n_cpp_xxx 时调 ---- */ \
    PBXEXPORT PBXRESULT PBXCALL PBX_CreateNonVisualObject(              \
        IPB_Session *session, pbobject obj, LPCTSTR className,          \
        IPBX_NonVisualObject **nvobj)                                   \
    {                                                                   \
        std::vector<PBNINvoInfo> &_r = NvoReg();                        \
        for (size_t _i = 0; _i < _r.size(); _i++)                       \
            if (_tcscmp(className, _r[_i].name) == 0) {                \
                /* 调用工厂函数 new 出 C++ 对象，返回给 PB */            \
                *nvobj = (IPBX_NonVisualObject*)_r[_i].create(session); \
                return PBX_OK;                                          \
            }                                                           \
        return PBX_E_NO_SUCH_CLASS;                                     \
    }                                                                   \
                                                                        \
    /* ---- PBX_CreateVisualObject：PB 创建可视控件时调 ---- */          \
    PBXEXPORT PBXRESULT PBXCALL PBX_CreateVisualObject(                 \
        IPB_Session *session, pbobject obj, LPCTSTR className,          \
        IPBX_VisualObject **vobj)                                       \
    {                                                                   \
        std::vector<PBNIVisualInfo> &_r = VisualReg();                  \
        for (size_t _i = 0; _i < _r.size(); _i++)                       \
            if (_tcscmp(className, _r[_i].name) == 0) {                \
                *vobj = (IPBX_VisualObject*)_r[_i].create(session, obj);\
                return PBX_OK;                                          \
            }                                                           \
        return PBX_E_NO_SUCH_CLASS;                                     \
    }                                                                   \
                                                                        \
    /* ---- PBX_InvokeGlobalFunction：PB 调全局函数时调 ---- */          \
    PBXEXPORT PBXRESULT PBXCALL PBX_InvokeGlobalFunction(               \
        IPB_Session *session, LPCTSTR funcName, PBCallInfo *ci)         \
    {                                                                   \
        std::vector<PBNIGlobalInfo> &_r = GlobalReg();                  \
        for (size_t _i = 0; _i < _r.size(); _i++)                       \
            if (_tcscmp(funcName, _r[_i].name) == 0)                   \
                return _r[_i].func(session, ci);                        \
        return PBX_E_INVOKE_METHOD_AMBIGUOUS;                           \
    }                                                                   \
                                                                        \
    /* ---- PBX_DrawVisualObject：PB 设计器绘制 Visual 控件时调 ---- */  \
    PBXEXPORT PBXRESULT PBXCALL PBX_DrawVisualObject(                   \
        HDC hDC, LPCTSTR className, const PBX_DrawItemStruct &property) \
    {                                                                   \
        /* 默认空实现。需在设计器预览的控件可自行覆盖此函数 */             \
        (void)hDC; (void)className; (void)property;                     \
        return PBX_OK;                                                  \
    }


//==========================================================================
//  七、用户宏 —— NVO（非可视对象）
//
//  最常用的类型。三步：
//    ① PBNI_REGISTER_NVO_BEGIN ... PBNI_REGISTER_NVO_END    方法表
//    ② PBNI_REGISTER_NVO_INVOKE ... PBNI_INVOKE_END         Invoke 分发
//    ③ 写业务方法
//
//  用法示例：
//    PBNI_REGISTER_NVO_BEGIN(MyMath, "n_cpp_math", "nonvisualobject")
//        PBNI_FUNC(0, "function string of_hello()")
//        PBNI_FUNC(1, "function int of_add(int a, int b)")
//    PBNI_REGISTER_NVO_END
//
//    PBNI_REGISTER_NVO_INVOKE(MyMath)
//        PBNI_INVOKE_CASE(0, Hello)
//        PBNI_INVOKE_CASE(1, Add)
//    PBNI_INVOKE_END
//==========================================================================

// PBNI_FUNC(id, "PB声明字符串") —— 在方法表数组里加一项
#define PBNI_FUNC(id, sig)  { id, _T(sig) },

// PBNI_REGISTER_NVO_BEGIN(类名, "PB类名", "PB父类")
// 定义 desc_name、desc_base、mt[] 三个静态变量供后续宏使用
#define PBNI_REGISTER_NVO_BEGIN(ClsName, pbName, baseType)              \
    static LPCTSTR ClsName##_desc_name = _T(pbName);                    \
    static LPCTSTR ClsName##_desc_base = _T(baseType);                  \
    static PBNIMethod ClsName##_mt[] = {

// 关闭方法表数组（所有四类方法表结构相同，共用此 END 或下列别名）
#define PBNI_REGISTER_NVO_END                                           \
    };
#define PBNI_REGISTER_VISUAL_END    PBNI_REGISTER_NVO_END
#define PBNI_REGISTER_MARSHALER_END PBNI_REGISTER_NVO_END

// PBNI_REGISTER_NVO_INVOKE(类名)
// 生成：工厂函数 + 注册入表 + Invoke 分发函数头（switch 开始）
// 注意：MSVC 要求在派生类体内用 PBNI_NVO_INVOKE_DECL 声明 Invoke，再在类外用本宏定义
#define PBNI_NVO_INVOKE_DECL \
    virtual PBXRESULT Invoke(IPB_Session*, pbobject, pbmethodID, PBCallInfo*);

#define PBNI_REGISTER_NVO_INVOKE(ClsName)                               \
    static void *ClsName##_factory(IPB_Session *s) {                    \
        return new ClsName(s);   /* 工厂：PB 每次 CREATE 都走这里 */     \
    }                                                                   \
    PBNI_ADD_NVO(ClsName, ClsName##_factory)   /* 注册到 NVO 表 */      \
    PBXRESULT ClsName::Invoke(                                          \
        IPB_Session*, pbobject, pbmethodID mid, PBCallInfo *ci)         \
    {                                                                   \
        switch (mid) {          /* 生成 switch(mid) {} 体 */            \

// PBNI_INVOKE_CASE(编号, 方法名) —— 一条 case 分支
#define PBNI_INVOKE_CASE(id, methodName)                                \
            case id: return this->methodName(ci);

// 关闭 switch：default → 返回错误码
#define PBNI_INVOKE_END                                                 \
            default: return PBX_E_INVOKE_METHOD_AMBIGUOUS;             \
        }                                                               \
    }


//==========================================================================
//  八、用户宏 —— Visual（可视控件）
//
//  三步：
//    ① PBNI_REGISTER_VISUAL_BEGIN ... PBNI_REGISTER_VISUAL_END  方法表
//    ② PBNI_REGISTER_VISUAL_INVOKE ... PBNI_VISUAL_INVOKE_END   Invoke
//    ③ 实现 Visual 必需方法
//
//  推荐继承 PBNIVisualBase（框架提供，减少样板）。
//  也可直接继承 IPBX_VisualObject 并自行实现全部 7 个方法。
//==========================================================================

// 定义钩子函数 + desc_name + mt[]
#define PBNI_REGISTER_VISUAL_BEGIN(ClsName, pbName)                     \
    /* DllMain 加载钩子：调 RegisterWndClass */                          \
    static void ClsName##_init_hook(HINSTANCE h) {                      \
        ClsName::RegisterWndClass(h);                                   \
    }                                                                   \
    /* DllMain 卸载钩子：调 UnregisterWndClass */                        \
    static void ClsName##_cleanup_hook(HINSTANCE h) {                   \
        ClsName::UnregisterWndClass(h);                                 \
    }                                                                   \
    static LPCTSTR ClsName##_desc_name = _T(pbName);                    \
    static PBNIMethod ClsName##_mt[] = {

// 生成工厂 + 注册 + Invoke
#define PBNI_VISUAL_INVOKE_DECL \
    virtual PBXRESULT Invoke(IPB_Session*, pbobject, pbmethodID, PBCallInfo*);

#define PBNI_REGISTER_VISUAL_INVOKE(ClsName)                            \
    static void *ClsName##_factory(IPB_Session *s, pbobject o) {        \
        return new ClsName(s, o);                                       \
    }                                                                   \
    PBNI_ADD_VISUAL(ClsName, ClsName##_factory)                         \
    PBXRESULT ClsName::Invoke(                                          \
        IPB_Session*, pbobject, pbmethodID mid, PBCallInfo *ci)         \
    {                                                                   \
        switch (mid) {

#define PBNI_VISUAL_INVOKE_CASE(id, methodName)                         \
            case id: return this->methodName(ci);

#define PBNI_VISUAL_INVOKE_END                                          \
            default: return PBX_E_INVOKE_METHOD_AMBIGUOUS;             \
        }                                                               \
    }


//==========================================================================
//  九、用户宏 —— 全局函数
//
//  一步搞定。注意：必须手动写 return PBX_OK;
//
//  用法示例：
//    PBNI_REGISTER_GLOBAL_BEGIN(f_version, "function string f_version()")
//    {
//        ci->returnValue->SetString(_T("v1.0"));
//        return PBX_OK;
//    }
//    PBNI_REGISTER_GLOBAL_END(f_version)   // ← 注意：必须和 BEGIN 的名字一致
//==========================================================================

#define PBNI_REGISTER_GLOBAL_BEGIN(FuncName, sig)                       \
    static LPCTSTR FuncName##_desc_name = _T(#FuncName);                \
    static LPCTSTR FuncName##_desc_sig  = _T(sig);                      \
    static PBXRESULT FuncName##_body(IPB_Session *s, PBCallInfo *ci)    \
    {      /* 用户代码从这里开始，类似于写一个普通 C++ 函数 */            \

#define PBNI_REGISTER_GLOBAL_END(FuncName)                               \
    }      /* 用户代码到这里结束 */                                       \
    PBNI_ADD_GLOBAL(FuncName)    /* 自动注册到全局函数表 */


//==========================================================================
//  十、用户宏 —— Marshaler（远程代理）
//
//  三步：
//    ① PBNI_REGISTER_MARSHALER_BEGIN ... PBNI_REGISTER_MARSHALER_END  方法表
//    ② PBNI_REGISTER_MARSHALER_INVOKE ... PBNI_MARSHALER_INVOKE_END   Invoke
//    ③ 写业务方法
//
//  区别：InvokeRemoteMethod 按方法签名字符串匹配，不用 mid。
//
//  注意：类必须继承 PBNIMarshalerBase。工厂函数不会被 PB 自动调用——
//        用户需在 PB 端通过 NewProxyObject + SetMarshaler 手动绑定。
//==========================================================================

#define PBNI_REGISTER_MARSHALER_BEGIN(ClsName, pbName)                  \
    static LPCTSTR ClsName##_desc_name = _T(pbName);                    \
    static PBNIMethod ClsName##_mt[] = {

#define PBNI_MARSHALER_INVOKE_DECL \
    virtual PBXRESULT InvokeRemoteMethod(IPB_Session*, pbproxyObject, LPCTSTR, PBCallInfo*);

#define PBNI_REGISTER_MARSHALER_INVOKE(ClsName)                         \
    static void *ClsName##_factory(IPB_Session *s, pbproxyObject o) {   \
        return new ClsName(s, o);                                       \
    }                                                                   \
    PBNI_ADD_MARSHALER(ClsName, ClsName##_factory)                      \
    PBXRESULT ClsName::InvokeRemoteMethod(                              \
        IPB_Session *s, pbproxyObject o, LPCTSTR methodDesc, PBCallInfo *ci) \
    {                                                                   \
        /* Marshaler 按方法签名（字符串）匹配，与 NVO 的 mid 方式不同 */   \
        static const int _count =                                       \
            sizeof(ClsName##_mt) / sizeof(PBNIMethod);                  \
        for (int _i = 0; _i < _count; _i++) {                           \
            if (_tcscmp(methodDesc, ClsName##_mt[_i].signature) == 0) { \
                /* 匹配到签名 → 用 mid 做 switch */                      \
                switch (ClsName##_mt[_i].mid) {

#define PBNI_MARSHALER_CASE(mid, methodName)                            \
                    case mid: return this->methodName(s, o, ci);

#define PBNI_MARSHALER_INVOKE_END                                       \
                }                                                       \
            }                                                           \
        }                                                               \
        return PBX_E_INVOKE_METHOD_AMBIGUOUS;                           \
    }

#endif // PBNILIB_H
