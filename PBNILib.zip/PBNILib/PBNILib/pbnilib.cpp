#include "pbnilib.h"

PBNIHost::~PBNIHost()
{
    if (d_session) { d_session->Release(); d_session = NULL; }
}

IPB_Session* PBNIHost::Start(LPCTSTR appName, LPCTSTR cmdLine)
{
    if (d_session) {
        d_session->Release();
        d_session = NULL;
    }

    IPB_VM *vm = NULL;
    if (PB_GetVM(&vm) != PBX_OK || !vm) return NULL;

    IPB_Session *session = NULL;

    PBXRESULT r = vm->CreateSession(appName, NULL, 0, &session);
    if (r != PBX_OK && cmdLine && cmdLine[0] != 0)
    {
        r = vm->RunApplication(appName, NULL, 0, cmdLine, &session);
    }

    if (r != PBX_OK || !session) return NULL;

    d_session = session;
    return d_session;
}
