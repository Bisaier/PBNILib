﻿#include "pbnilib.h"
// 永远只有 2 行 —— 包含头文件 + 调用 PBNI_DLL_MAIN
PBNI_DLL_MAIN()
