﻿#include "MyMath.h"

// ① 方法表
PBNI_REGISTER_NVO_BEGIN(MyMath, "n_cpp_math", "nonvisualobject")
    PBNI_FUNC(0, "function string of_hello()")
    PBNI_FUNC(1, "function int of_add(int a, int b)")
PBNI_REGISTER_NVO_END

// ② Invoke 分发
PBNI_REGISTER_NVO_INVOKE(MyMath)
    PBNI_INVOKE_CASE(0, Hello)
    PBNI_INVOKE_CASE(1, Add)
PBNI_INVOKE_END

// ③ 业务实现
PBXRESULT MyMath::Hello(PBCallInfo *ci) {
    ci->returnValue->SetString(_T("Hello from C++!"));
    return PBX_OK;
}

PBXRESULT MyMath::Add(PBCallInfo *ci) {
    pbint a = ci->pArgs->GetAt(0)->GetInt();
    pbint b = ci->pArgs->GetAt(1)->GetInt();
    ci->returnValue->SetInt(a + b);
    return PBX_OK;
}
