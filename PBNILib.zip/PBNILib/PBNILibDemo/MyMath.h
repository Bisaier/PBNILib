﻿#ifndef PBNILIBDEMO_MYMATH_H
#define PBNILIBDEMO_MYMATH_H

#include "pbnilib.h"

class MyMath : public PBNIBase
{
public:
    MyMath(IPB_Session *s) : PBNIBase(s) {}
    PBXRESULT Hello(PBCallInfo *ci);
    PBXRESULT Add(PBCallInfo *ci);
    PBNI_NVO_INVOKE_DECL   // MSVC 要求派生类体内显式声明 Invoke
};

#endif
