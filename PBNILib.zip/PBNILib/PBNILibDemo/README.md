# PBNILibDemo

## 编译

### 前提
- Visual Studio 2010（或更高，必须 32 位编译）
- PowerBuilder 12.5（需要 `PBNI\include\` 和 `PBNI\lib\PBNI.LIB`）

### 目录结构

```
PBNILibDemo/
├── main.cpp         ← 入口（2 行）
├── MyMath.h         ← NVO 类声明
├── MyMath.cpp       ← 注册宏 + 业务实现
└── README.md
```

### VS2010 项目配置

| 设置项 | 值 |
|--------|-----|
| 项目类型 | Win32 DLL |
| 字符集 | 使用 Unicode 字符集 |
| C/C++ → 附加包含目录 | `..\PBNILib` + `..\PBNI\include` |
| 链接器 → 附加依赖项 | `..\PBNI\lib\PBNI.LIB` |

### 编译步骤

```
1. VS2010 新建 → Win32 项目 → DLL → 空项目
2. 添加 main.cpp、MyMath.h、MyMath.cpp 到项目
3. 按上表配置包含目录和链接依赖
4. F7 编译
```

### 导入 PB

```
PB IDE → 右键 PBL → Import PB Extension → 选择生成的 DLL
PB 脚本: CREATE n_cpp_math → 调用 of_hello() / of_add()
```
